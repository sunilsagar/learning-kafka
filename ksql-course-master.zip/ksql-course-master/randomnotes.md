```
  527  export CONFLUENT_HOME=/opt/kafka
  528  export  CONFLUENT_CURRENT=/mnt/d/kafka-data/
```  


RHEL, Debian, Ubuntu 
macOS is supported for testing and development purposes only.
Windows - WSL for Windows 10 - Windows Subsystem for Linux
, and it allows you to run Linux environments directly on Windows in a native format and without the overhead of a virtual machine
If you do this , remember once WSL is enabled you need to download and install a distro from the Windows Store usch as Ubuntu, 

Confluent 5.2 uses Java 11 
JDK 1.8 → u31 or later, JDK 11.0.0 or later

https://docs.confluent.io/current/installation/installing_cp/zip-tar.html#prod-kafka-cli-install

curl -O http://packages.confluent.io/archive/5.2/confluent-5.2.1-2.12.zip


sudo rm confluent



java -version

curl -O http://packages.confluent.io/archive/5.2/confluent-community-5.2.1-2.12.zip
sudo mv confluent-5.2.1/ /opt
cd /opt
sudo ln -s confluent-5.2.1 confluent
export PATH=${PATH}:/opt/confluent/bin
which  confluent

confluent start ksql-server
confluent status
ksql

vi ~/.bash_profile

java -version
df -h
ksql

confluent stop
confluent start ksql-server

# A Table
If we consider the 

messages arriving into a topic as independent and unbounded sequence of structured values, we interpret the topic as a stream. 

Messages in a stream do not have any relation with each other and will be processed independently.



On the other hand, if we consider the messages arriving into a
topic as an evolving set of messages where a new message either
updates the previous message in the set with the same key, or
adds a new message when there is no message with the same
key, then we interpret the topic as a table. Note that a table is an
state-full entity since we need to keep track of the latest values
for each key. In other words, if we interpret the messages in a
topic as a change log with a state store that represent the latest
state, then we interpret the topic as a table.
As an example consider we store the page view events for a
website in a Kafka topic. In this case, we should interpret the
topic as a stream since each view is an independent message. On
the other hand, consider we are storing user information is a
Kafka topic where each message either adds a new user if