
Once off
```
virtualenv ksqlpython
source ksqlpython/bin/activate
pip install ksql
```

Each time you want to run
```
source ksqlpython/bin/activate
python ./ksql-python.py
```
